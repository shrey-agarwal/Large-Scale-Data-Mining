The project has been developed and tested in python2 as well as python3 for compatibility. 
But we highly recommend python3

The structure is as follows:
There is one file, 1 python notebook (ipynb)

To run the files:
If you already have pre-trained models
1. Set the "load_from_previous" to true
2. Put the models in "models" folder in the same location as the programs.
3. Put the data in data folder. (download from the pdf link)

Otherwise you will have to set the "load_from_previous" to false.
By default, we have set the "load_from_previous" to true so that all the pre-trained models are used.
We have also included all the models for the ease of and testing the code.
No other changes are required to run the file project3.ipynb.

